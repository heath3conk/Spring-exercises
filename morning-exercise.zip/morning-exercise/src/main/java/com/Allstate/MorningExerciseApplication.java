package com.Allstate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MorningExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(MorningExerciseApplication.class, args);
	}
}
